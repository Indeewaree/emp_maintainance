﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeMaintenanceASP
{
    public class Employee
    {
        public int EmpNo { get; set; }
        public string Name { get; set; }
        public decimal Salary { get; set; }
        public string DeptCode { get; set; }
        public string Dob { get; set; }

        public void SaveEmployee(Employee emp)
        {
            string sql = "insert into employee (Name, Salary, deptCode, Dob) values " +
                "('" + emp.Name + "'," + emp.Salary + ",'" + emp.DeptCode + "','" + emp.Dob + "')";

            Data.ExecuteQuery(sql);
        }

        public void UpdateEmployee(Employee emp)
        {
            string sql = "update employee set Name='" + emp.Name + "',Salary=" + emp.Salary + ",Dob='" + emp.Dob + "',deptCode='" + emp.DeptCode + "' where EmpNo='" + emp.EmpNo + "'";

            Data.ExecuteQuery(sql);
        }

        public void DeleteEmployee(Employee emp)
        {
            string sql = "delete from employee where EmpNo=" + emp.EmpNo;

            Data.ExecuteQuery(sql);
        }
    }
}